package com.example.myapplication.db;

import java.util.ArrayList;

public class ReadOnlyDataStorage {
    public static ArrayList<DBBranchingLogicInfo> branchingLogicInfoArrayList;
    public static ArrayList<DBAnswerInfo> answerInfoArrayList;
    public static ArrayList<DBHeadacheCatInfo> headacheCatInfoArrayList;

    public static ArrayList<DBMultiBranchLogicInfo> multiBranchLogicInfoArrayList;

}
